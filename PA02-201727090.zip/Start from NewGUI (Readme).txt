I have faced some difficulties when trying to create the UI for the NewGUI.py

Somehow there is an issue that I encountered last minute where if I type a number in the text field, I get two numbers at the same time! and I did not know how to solve it honestly so please paste the number in the text fields and I am really sorry.

The code is in good shape, only the NewGUI.py has some issues.

Thank you doctor.