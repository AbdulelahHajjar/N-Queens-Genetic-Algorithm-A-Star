class BTBoard():
    def __init__(self, indices=None):
        self.indices = indices
